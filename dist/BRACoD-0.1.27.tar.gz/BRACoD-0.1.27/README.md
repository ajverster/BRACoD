# BRACoD

Installation: 
Clone the repo.
Install the python requirements with pip install -r requirements.txt
If you want to use the R interface, install reticulate in R


Walkthrough

1. Simulate some data

2. Run BRACoD

3. Examine the diagnostics

4. Compare the results to the simulated truth
